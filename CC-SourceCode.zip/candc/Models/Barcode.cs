﻿namespace CC.Models
{
    public class Barcode
    {
        public string LotNumber { get; set; }
        public string ExpirationDate { get; set; }
        public string AntigenName { get; set; }
    }
}
