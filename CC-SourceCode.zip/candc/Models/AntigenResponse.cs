﻿namespace CC.Models
{
    public class AntigenResponse : BaseModel
    {
        public Antigen Antigen { get; set; }
    }
}
