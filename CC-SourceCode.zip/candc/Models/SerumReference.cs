﻿namespace CC.Models
{
    public class SerumReference
    {
        public string ReferenceNumber { get; set; }
    }
}
