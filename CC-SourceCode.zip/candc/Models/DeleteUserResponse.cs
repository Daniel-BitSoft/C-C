﻿namespace CC.Models
{
    public class DeleteUserResponse
    {
        public bool IsSuccesful { get; set; }

        public string ErrorMessage { get; set; }
    }
}
