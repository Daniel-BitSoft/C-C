﻿namespace CC.Models
{
    public class AntigensGroup
    {
        public string Group1 { get; set; }
        public string Group2 { get; set; }
        public string Group3 { get; set; }
        public string Group4 { get; set; }
        public string Group5 { get; set; }
        public string Group6 { get; set; }

    }
}
