﻿namespace CC.Models
{
    public class AntigenRange
    {
        public string AntigenId { get; set; }
        public string AntigenName { get; set; }
        public string Min { get; set; }
        public string Max { get; set; }
    }
}
