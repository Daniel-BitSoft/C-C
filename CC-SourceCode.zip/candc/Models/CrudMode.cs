﻿namespace CC.Models
{
    public enum CrudMode
    {
        Unknown,
        Create,
        Update
    }
}
