﻿namespace CC.Models
{
    public class BaseModel
    {
        public string ErrorMessage { get; set; }
    }
}
