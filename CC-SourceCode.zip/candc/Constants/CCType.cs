﻿namespace CC.Constants
{
    public enum CCType
    {
        P, // positive
        N, // negative
        C  // control
    }
}
