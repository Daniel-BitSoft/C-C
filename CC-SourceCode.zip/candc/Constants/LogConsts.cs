﻿namespace CC.Constants
{
    public class LogConsts
    {
        public static string Exception = nameof(Exception);
        public static string LogNumber = nameof(LogNumber);
    }
}
