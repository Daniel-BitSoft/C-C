﻿namespace CC.Constants
{
    public class UsersConsts
    {
        public const string DefaultTempPassword = "12345a";
        public const string PasswordRegex = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{6,}$";
    }
}
