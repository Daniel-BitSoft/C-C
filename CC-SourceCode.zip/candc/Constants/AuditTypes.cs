﻿namespace CC.Constants
{
    public enum AuditTypes
    {
        User,
        Antigen,
        Array,
        PosCalibrator,
        Control,
        NegCalibrator,
        ArrayAntigen,
        Batch
    }
}
